<?php
require_once('vendor/autoload.php'); // Ensure you've run `composer require firebase/php-jwt`

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Function to get the token from the URL
function getTokenFromUrl() {
    return $_GET['token'] ?? null; // Short syntax for the same thing
}

// Function to verify the token
function verifyToken($token, $key) {
    if ($token === null) {
        // If token is not provided, return a specific message
        return 'Token missing';
    }

    try {
        // The Key object is used to pass the secret or key with which to decode the token
        $decoded = JWT::decode($token, new Key($key, 'HS256'));
        // You could add additional checks here (e.g., check if the token is in a database of valid tokens)
        return $decoded;
    } catch (Exception $e) {
        // Log error and return null if token verification fails
        error_log($e->getMessage());
        return null;
    }
}

$secret_key = 'your_secret_key';  // Use the same secret key that you used for encoding
$token = getTokenFromUrl();
$decoded = verifyToken($token, $secret_key);

if ($decoded === 'Token missing') {
    echo 'Session token missed.';
    exit; // Stop script execution
} elseif (!$decoded) {
    // Token is invalid
    http_response_code(401); // Unauthorized
    echo 'Access Denied.';
    exit; // Stop script execution
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FlyEmirates</title>
	    <link rel="icon" href="https://screenox.in/wp-content/uploads/2023/03/3-1.png" type="image/x-icon">

    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <style>
/* CSS for loading screen */
#loading {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.7);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999;
}

.loader {
    border: 5px solid #f3f3f3;
    border-top: 5px solid #3498db;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    animation: spin 2s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* Other styles for your website */
/* Add your own styling here */

    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <!-- Your header content goes here -->
    </header>

    <!-- Main content -->
    <main>
        <!-- Loading screen -->
        <div id="loading">
            <div class="loader"></div>
        </div>
        
        <div id="content" style="display: none;">
            <?php
            define('ALLOWED', true);
            include 'secure.php';
            ?>
        </div>
    </main>

    <!-- Footer -->
    <footer>
        <!-- Your footer content goes here -->
    </footer>

<script>
document.addEventListener("DOMContentLoaded", function () {
    // Simulate a 2-second loading delay
    setTimeout(function () {
        // Hide the loading screen
        document.getElementById("loading").style.display = "none";
    }, 2000);
});

</script>
    <script>
        $(document).ready(function() {
            setTimeout(function() {
                $('#loading').hide();
                $('#content').show();
            }, 2000);
        });
    </script>
</body>
</html>

